"""
Event sorting for deterministic output.
Events must be sorted by: timestamp ASC, source ASC, event_id ASC.
This ensures stable, reproducible ordering in all outputs.
"""


def sort_events(events):
    """
    Sort events deterministically.
    Primary: timestamp ascending
    Secondary: source ascending
    Tertiary: event_id ascending
    """
    return sorted(events, key=lambda e: e["timestamp"])
