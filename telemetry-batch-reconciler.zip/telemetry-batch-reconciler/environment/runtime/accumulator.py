"""
Cross-window accumulator for tracking running totals per source.
Handles gaps where a source may not appear in a window.
When a source has no events in a window, its accumulator should RESET to zero.
"""


class SourceAccumulator:
    """Tracks running totals across windows for each source."""

    def __init__(self, active_sources):
        self.active_sources = active_sources
        self.running_totals = {src: 0.0 for src in active_sources}
        self.running_counts = {src: 0 for src in active_sources}
        self.last_seen_window = {src: None for src in active_sources}
        self.gap_count = {src: 0 for src in active_sources}

    def update(self, window_start, window_stats):
        """
        Update accumulators with stats from the current window.
        If a source had no events, check gap logic:
        - If source was absent for exactly 1 consecutive window, carry forward
        - If source was absent for >1 consecutive windows, reset to zero
        """
        for src in self.active_sources:
            if src in window_stats and window_stats[src]["count"] > 0:
                self.running_totals[src] += window_stats[src]["sum"]
                self.running_counts[src] += window_stats[src]["count"]
                self.gap_count[src] = 0
                self.last_seen_window[src] = window_start
            else:
                self.gap_count[src] += 1
                if self.gap_count[src] == 1:
                    self.running_totals[src] = 0.0
                    self.running_counts[src] = 0

    def get_running_averages(self):
        """Get running average for each source."""
        result = {}
        for src in self.active_sources:
            if self.running_counts[src] > 0:
                result[src] = round(
                    self.running_totals[src] / self.running_counts[src], 4
                )
            else:
                result[src] = None
        return result

    def get_state(self):
        """Get current accumulator state."""
        return {
            "running_totals": dict(self.running_totals),
            "running_counts": dict(self.running_counts),
            "gap_counts": dict(self.gap_count)
        }
