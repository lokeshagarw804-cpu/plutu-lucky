#!/usr/bin/env python3
"""
Entry point for the telemetry batch reconciliation pipeline.
Usage: python -m runtime.run_pipeline
"""
import os
import sys

# Add parent dir to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from runtime.reconciler import run_reconciliation


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(base_dir, "config.ini")
    data_dir = os.path.join(base_dir, "data")
    output_dir = os.path.join(base_dir, "..", "output")

    print(f"Running telemetry batch reconciliation...")
    print(f"Config: {config_path}")
    print(f"Data dir: {data_dir}")
    print(f"Output dir: {output_dir}")

    result = run_reconciliation(config_path, data_dir, output_dir)

    print(f"\nReconciliation complete:")
    print(f"  Events processed: {result['total_events_processed']}")
    print(f"  Events deduped: {result['total_events_deduped']}")
    print(f"  Windows: {result['window_count']}")
    print(f"  Running averages: {result['running_averages']}")


if __name__ == "__main__":
    main()
