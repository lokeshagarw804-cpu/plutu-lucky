"""
Window assignment for telemetry events.
Windows are non-overlapping intervals of fixed size.
Window boundaries are [start, end) - start inclusive, end exclusive.
The first window starts at the minimum timestamp across all events.
"""


def assign_windows(events, window_size_sec):
    """
    Assign each event to a window based on its timestamp.
    Windows are [start, start + window_size_sec).
    Returns dict mapping window_start -> list of events.
    """
    if not events:
        return {}

    timestamps = [e["timestamp"] for e in events]
    min_ts = min(timestamps)

    base = min_ts

    windows = {}
    for event in events:
        ts = event["timestamp"]
        offset = ts - base

        if offset > 0 and offset % window_size_sec == 0:
            window_idx = (offset // window_size_sec) - 1
        else:
            window_idx = offset // window_size_sec

        window_start = base + window_idx * window_size_sec

        if window_start not in windows:
            windows[window_start] = []
        windows[window_start].append(event)

    return windows
