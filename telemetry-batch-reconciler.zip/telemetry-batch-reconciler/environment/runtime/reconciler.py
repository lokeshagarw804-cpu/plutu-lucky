"""
Main reconciliation pipeline.
Orchestrates: load -> deduplicate -> sort -> window -> aggregate -> accumulate -> report.
"""
import json
import os
import configparser

from .loader import load_batches
from .deduplicator import deduplicate_events
from .sorter import sort_events
from .windower import assign_windows
from .aggregator import aggregate_window
from .accumulator import SourceAccumulator


def load_config(config_path):
    """Load pipeline configuration."""
    config = configparser.ConfigParser()
    config.read(config_path)
    return config


def run_reconciliation(config_path, data_dir, output_dir):
    """Run the full reconciliation pipeline."""
    config = load_config(config_path)

    window_size = int(config["pipeline"]["window_size_sec"])
    dedup_strategy = config["pipeline"]["dedup_strategy"]
    precision = int(config["pipeline"]["precision"])
    active_sources = [s.strip() for s in config["sources"]["active_sources"].split(",")]

    # Step 1: Load all batch events
    all_events = load_batches(data_dir)

    # Step 2: Deduplicate
    deduped = deduplicate_events(all_events, strategy=dedup_strategy)

    # Step 3: Sort deterministically
    sorted_events = sort_events(deduped)

    # Step 4: Assign to windows
    windows = assign_windows(sorted_events, window_size)

    # Step 5: Aggregate per window
    accumulator = SourceAccumulator(active_sources)
    window_summaries = []

    for window_start in sorted(windows.keys()):
        window_events = windows[window_start]
        window_end = window_start + window_size

        stats = aggregate_window(window_events, active_sources)
        accumulator.update(window_start, stats)

        # Build per-window summary
        summary = {
            "window_start": window_start,
            "window_end": window_end,
            "event_count": len(window_events),
            "sources": stats,
            "sorted_event_ids": [e["event_id"] for e in sort_events(window_events)],
        }
        window_summaries.append(summary)

    # Step 6: Build settlement report
    settlement = {
        "total_events_processed": len(sorted_events),
        "total_events_deduped": len(all_events) - len(deduped),
        "window_count": len(windows),
        "window_size_sec": window_size,
        "running_averages": accumulator.get_running_averages(),
        "accumulator_state": accumulator.get_state(),
        "windows": window_summaries
    }

    # Write outputs
    os.makedirs(output_dir, exist_ok=True)

    report_path = os.path.join(output_dir, "settlement_report.json")
    with open(report_path, "w") as f:
        json.dump(settlement, f, indent=2)

    summary_path = os.path.join(output_dir, "window_summary.json")
    with open(summary_path, "w") as f:
        json.dump(window_summaries, f, indent=2)

    return settlement
