"""
Deduplication engine for telemetry events.
Retried events share the same correlation_id with the original.
Deduplication should keep only the LATEST event per correlation_id
(highest timestamp, or highest event_id as tiebreaker).
"""


def deduplicate_events(events, strategy="correlation_id"):
    """
    Remove duplicate events based on dedup strategy.
    For retries: keep the event with the latest timestamp per correlation_id.
    If timestamps are equal, keep the one with the higher event_id.
    """
    seen = {}

    for event in events:
        key = event["event_id"]

        if key not in seen:
            seen[key] = event
        else:
            existing = seen[key]
            if event["timestamp"] > existing["timestamp"]:
                seen[key] = event
            elif event["timestamp"] == existing["timestamp"]:
                if event["event_id"] > existing["event_id"]:
                    seen[key] = event

    return list(seen.values())
