"""
Per-window aggregation of telemetry events.
Computes per-source statistics within each window.
"""


def aggregate_window(events, active_sources):
    """
    Aggregate events within a single window.
    Returns per-source stats: count, sum, avg, min, max.
    Sources with no events in the window should report null stats.
    """
    source_data = {src: [] for src in active_sources}

    for event in events:
        src = event["source"]
        if src in source_data:
            source_data[src].append(event["value"])

    result = {}
    for src in active_sources:
        values = source_data[src]
        if not values:
            result[src] = {
                "count": 0,
                "sum": 0.0,
                "avg": None,
                "min": None,
                "max": None
            }
        else:
            total = sum(values)
            count = len(values)
            if total == int(total):
                avg = int(total) // count
            else:
                avg = total / count

            result[src] = {
                "count": count,
                "sum": round(total, 4),
                "avg": round(avg, 4),
                "min": round(min(values), 4),
                "max": round(max(values), 4)
            }

    return result
