"""
Loads telemetry batch files from the data directory.
"""
import json
import os
import glob


def load_batches(data_dir):
    """Load all batch JSON files from data directory, sorted by filename."""
    batch_files = sorted(glob.glob(os.path.join(data_dir, "batch_*.json")))
    all_events = []
    for bf in batch_files:
        with open(bf, "r") as f:
            events = json.load(f)
            all_events.extend(events)
    return all_events
