# Telemetry Batch Reconciler — Debug Report

The telemetry batch reconciliation pipeline (`environment/runtime/`) is producing incorrect settlement reports. We noticed the issues during nightly reconciliation audits against our ground truth station data.

## Symptoms

1. **Duplicate events persist in output** — retry events that should be collapsed by `correlation_id` still appear as separate entries in the settlement report.

2. **Window event ordering is non-deterministic** — the `sorted_event_ids` arrays differ between runs even though input data is static. Events sharing timestamps appear in arbitrary order.

3. **Window boundary assignment is wrong** — events landing exactly on a window boundary (e.g., timestamp 1700000060 with window size 60, base 1700000010) end up in the previous window instead of the next.

4. **Source running averages are incorrect** — the cross-window accumulator seems to reset/carry values at the wrong times. A source missing one window should carry forward, but it resets. Sources missing two or more windows keep stale values.

5. **Per-window averages have precision errors** — some averages show integer-truncated values instead of proper floating-point means.

## Expected behavior

Run with `cd environment && python -m runtime.run_pipeline`. Output goes to `environment/output/`. The settlement report should contain deterministic event ordering, correct deduplication counts, proper window assignments, accurate per-source averages, and correct accumulator state.

## Files

- `runtime/deduplicator.py`
- `runtime/sorter.py`
- `runtime/windower.py`
- `runtime/accumulator.py`
- `runtime/aggregator.py`
- `runtime/reconciler.py`
- `runtime/config.ini`
- `runtime/data/batch_*.json`
