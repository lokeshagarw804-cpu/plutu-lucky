#!/bin/bash

# Run the pipeline first to generate outputs
cd /app && python -m runtime.run_pipeline

# Run test suite
pytest tests/test_outputs.py -rA
