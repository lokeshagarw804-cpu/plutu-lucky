"""
Test suite for the telemetry batch reconciliation pipeline.
Validates settlement report correctness, deduplication, windowing,
ordering, accumulation, and aggregation.
"""
import json
import os
import hashlib

# Paths
RUNTIME_DIR = "/app/runtime"
DATA_DIR = "/app/runtime/data"
OUTPUT_DIR = "/app/output"
REPORT_PATH = os.path.join(OUTPUT_DIR, "settlement_report.json")
SUMMARY_PATH = os.path.join(OUTPUT_DIR, "window_summary.json")


def get_report():
    """Load the settlement report."""
    with open(REPORT_PATH) as f:
        return json.load(f)


def get_summary():
    """Load the window summary."""
    with open(SUMMARY_PATH) as f:
        return json.load(f)


def get_data_hash():
    """Compute hash of all batch data files to verify integrity."""
    hasher = hashlib.sha256()
    batch_files = sorted(
        f for f in os.listdir(DATA_DIR)
        if f.startswith("batch_") and f.endswith(".json")
    )
    for bf in batch_files:
        with open(os.path.join(DATA_DIR, bf), "rb") as f:
            hasher.update(f.read())
    return hasher.hexdigest()


# --- Data integrity ---

def test_data_integrity():
    """Verify input data files are intact and dedup produces correct count."""
    batch_files = sorted(
        f for f in os.listdir(DATA_DIR)
        if f.startswith("batch_") and f.endswith(".json")
    )
    assert len(batch_files) == 3, f"Expected 3 batch files, got {len(batch_files)}"
    total_raw = 0
    retry_count = 0
    for bf in batch_files:
        with open(os.path.join(DATA_DIR, bf)) as f:
            events = json.load(f)
        total_raw += len(events)
        for e in events:
            assert "event_id" in e
            assert "correlation_id" in e
            if e["retry"]:
                retry_count += 1
    assert total_raw == 45, f"Raw event total {total_raw} != 45"
    assert retry_count == 4, f"Retry event count {retry_count} != 4"
    # Verify settlement report reflects correct dedup
    report = get_report()
    assert report["total_events_deduped"] == retry_count


def test_output_files_exist():
    """Verify that both output files are generated and contain valid JSON."""
    assert os.path.isfile(REPORT_PATH), "settlement_report.json missing"
    assert os.path.isfile(SUMMARY_PATH), "window_summary.json missing"
    report = get_report()
    assert "total_events_processed" in report
    assert "windows" in report
    assert report["total_events_processed"] < 45, (
        "Processed count equals raw count - deduplication not working"
    )


# --- Deduplication tests ---

def test_dedup_total_count():
    """After deduplication, exactly 4 events should be removed (4 retries replace originals)."""
    report = get_report()
    assert report["total_events_deduped"] == 4, (
        f"Expected 4 deduped events, got {report['total_events_deduped']}"
    )


def test_dedup_processed_count():
    """After deduplication, 41 unique events should remain for processing."""
    report = get_report()
    assert report["total_events_processed"] == 41, (
        f"Expected 41 processed events, got {report['total_events_processed']}"
    )


def test_dedup_retries_collapsed():
    """Retry events must be collapsed - correlation_id 'cor_001' should appear only once."""
    report = get_report()
    all_event_ids = []
    for w in report["windows"]:
        all_event_ids.extend(w["sorted_event_ids"])
    # evt_001 should be gone (replaced by evt_007 retry)
    assert "evt_001" not in all_event_ids, "evt_001 should be deduped by retry evt_007"
    # evt_007 (the retry) should exist
    assert "evt_007" in all_event_ids, "evt_007 (retry for cor_001) should be present"


def test_dedup_keeps_latest_timestamp():
    """Dedup should keep the event with the latest timestamp per correlation_id."""
    report = get_report()
    all_event_ids = []
    for w in report["windows"]:
        all_event_ids.extend(w["sorted_event_ids"])
    # cor_004: evt_004 (ts 1700000045) vs evt_013 (ts 1700000105) - keep evt_013
    assert "evt_004" not in all_event_ids, "evt_004 should be replaced by evt_013"
    assert "evt_013" in all_event_ids, "evt_013 should be kept as latest for cor_004"
    # cor_026: evt_029 (ts 1700000240) vs evt_034 (ts 1700000265) - keep evt_034
    assert "evt_029" not in all_event_ids, "evt_029 should be replaced by evt_034"
    assert "evt_034" in all_event_ids, "evt_034 should be kept as latest for cor_026"
    # cor_013: evt_015 (ts 1700000120) vs evt_020 (ts 1700000145) - keep evt_020
    assert "evt_015" not in all_event_ids, "evt_015 should be replaced by evt_020"
    assert "evt_020" in all_event_ids, "evt_020 should be kept as latest for cor_013"


# --- Window count and structure ---

def test_window_count():
    """Pipeline should produce exactly 6 windows with correct first window start."""
    report = get_report()
    assert report["window_count"] == 6, f"Expected 6 windows, got {report['window_count']}"
    # Verify first window starts at correct base timestamp
    summary = get_summary()
    assert summary[0]["window_start"] == 1700000015, (
        f"First window start {summary[0]['window_start']} != 1700000015"
    )


def test_window_size_and_continuity():
    """Windows must span 60 seconds, be contiguous, and start at 1700000015."""
    summary = get_summary()
    assert summary[0]["window_start"] == 1700000015, (
        f"First window must start at 1700000015, got {summary[0]['window_start']}"
    )
    for w in summary:
        span = w["window_end"] - w["window_start"]
        assert span == 60, f"Window span {span} != 60"
    for i in range(1, len(summary)):
        assert summary[i]["window_start"] == summary[i-1]["window_end"], (
            f"Gap between window {i-1} and {i}"
        )


def test_first_window_start():
    """First window should start at minimum timestamp of deduped events (1700000015)."""
    summary = get_summary()
    # After dedup, min timestamp is evt_002 at 1700000015 (evt_001 deduped by cor_001)
    assert summary[0]["window_start"] == 1700000015, (
        f"First window start {summary[0]['window_start']} != 1700000015"
    )


# --- Sort stability / ordering ---

def test_sort_deterministic_same_timestamp():
    """Events at the same timestamp must be sorted by source ASC, then event_id ASC."""
    summary = get_summary()
    # Window at 1700000315: events at ts 1700000360 include
    # sensor_a (evt_044), sensor_b (evt_045), sensor_c (evt_043), sensor_d (evt_042)
    last_window = summary[-1]
    ids = last_window["sorted_event_ids"]
    # The last 4 events (at ts 1700000360) must be in source order
    boundary_events = ids[-4:]
    assert boundary_events == ["evt_044", "evt_045", "evt_043", "evt_042"], (
        f"Expected ['evt_044', 'evt_045', 'evt_043', 'evt_042'], got {boundary_events}"
    )


def test_sort_window2_ordering():
    """Window 2 contains events at ts 1700000120 from multiple sources - must be stable."""
    summary = get_summary()
    w2 = summary[1]
    ids = w2["sorted_event_ids"]
    # ts 1700000120: sensor_a (evt_017), sensor_d (evt_016)
    # sensor_a < sensor_d alphabetically, so evt_017 before evt_016
    idx_017 = ids.index("evt_017")
    idx_016 = ids.index("evt_016")
    assert idx_017 < idx_016, (
        f"evt_017 (sensor_a) should come before evt_016 (sensor_d) at same timestamp"
    )


def test_sort_full_ordering_window1():
    """Window 1 sorted_event_ids must be in exact deterministic order."""
    summary = get_summary()
    w1 = summary[0]
    expected = ["evt_002", "evt_003", "evt_005", "evt_006", "evt_007", "evt_008", "evt_009"]
    assert w1["sorted_event_ids"] == expected, (
        f"Window 1 ordering mismatch: {w1['sorted_event_ids']} != {expected}"
    )


# --- Window boundary assignment ---

def test_boundary_event_assignment():
    """Events at exact window boundaries go to the NEW window, not the previous."""
    summary = get_summary()
    # Window base is 1700000015, window size 60
    # ts 1700000075 = base + 60 -> should go to window starting at 1700000075
    w2 = summary[1]  # window_start = 1700000075
    assert w2["window_start"] == 1700000075
    ids = w2["sorted_event_ids"]
    assert "evt_010" in ids, (
        "evt_010 (ts 1700000075) should be in window starting at 1700000075"
    )
    # evt_010 should NOT be in window 1
    w1 = summary[0]
    assert "evt_010" not in w1["sorted_event_ids"], (
        "evt_010 should not be in first window"
    )


def test_boundary_event_count_window1():
    """First window [1700000015, 1700000075) should have exactly 7 events."""
    summary = get_summary()
    w1 = summary[0]
    assert w1["event_count"] == 7, f"Window 1 event count {w1['event_count']} != 7"


def test_window4_event_ids():
    """Window 4 (1700000195-1700000255) must contain exactly 6 specific events."""
    summary = get_summary()
    w4 = summary[3]
    assert w4["window_start"] == 1700000195
    assert w4["event_count"] == 6
    expected_ids = sorted(["evt_026", "evt_027", "evt_028", "evt_030", "evt_031", "evt_032"])
    actual_ids = sorted(w4["sorted_event_ids"])
    assert actual_ids == expected_ids, (
        f"Window 4 event IDs mismatch: {actual_ids} != {expected_ids}"
    )


# --- Aggregation precision ---

def test_avg_precision_window3_sensor_b():
    """sensor_b window 3 avg: 63.7/3 = 21.2333, must not be integer truncated."""
    summary = get_summary()
    w3 = summary[2]
    assert w3["window_start"] == 1700000135
    avg_b = w3["sources"]["sensor_b"]["avg"]
    assert abs(avg_b - 21.2333) < 0.001, (
        f"sensor_b window 3 avg {avg_b} != 21.2333"
    )


def test_avg_precision_sensor_a_window1():
    """sensor_a window 1: sum=75.9, count=3, avg should be 25.3 exactly."""
    summary = get_summary()
    w1 = summary[0]
    avg_a = w1["sources"]["sensor_a"]["avg"]
    assert avg_a == 25.3, f"sensor_a window 1 avg {avg_a} != 25.3"


def test_avg_no_integer_division():
    """sensor_a window 2: 72.9/3 = 24.3; also sensor_d window 6: 18.0/1 = 18.0 (float)."""
    summary = get_summary()
    w2 = summary[1]
    avg_a = w2["sources"]["sensor_a"]["avg"]
    assert avg_a == 24.3, f"sensor_a window 2 avg {avg_a} != 24.3 (integer division bug?)"
    # Also verify window 2 starts correctly
    assert w2["window_start"] == 1700000075, (
        f"Window 2 start {w2['window_start']} != 1700000075"
    )


def test_avg_sensor_c_window1():
    """sensor_c window 1 should have count=1 and avg=29.4 (only evt_009)."""
    summary = get_summary()
    w1 = summary[0]
    src_c = w1["sources"]["sensor_c"]
    assert src_c["count"] == 1, f"sensor_c window 1 count {src_c['count']} != 1"
    assert src_c["avg"] == 29.4, f"sensor_c window 1 avg {src_c['avg']} != 29.4"


# --- Accumulator / running averages ---

def test_running_avg_sensor_a():
    """Final running average for sensor_a should be 26.7538 (347.8/13)."""
    report = get_report()
    avg = report["running_averages"]["sensor_a"]
    assert abs(avg - 26.7538) < 0.001, f"sensor_a running avg {avg} != 26.7538"


def test_running_avg_sensor_c():
    """Final running average for sensor_c should be 33.65 (269.2/8)."""
    report = get_report()
    avg = report["running_averages"]["sensor_c"]
    assert abs(avg - 33.65) < 0.001, f"sensor_c running avg {avg} != 33.65"


def test_accumulator_total_counts():
    """Running counts must match exact per-source event counts after dedup."""
    report = get_report()
    counts = report["accumulator_state"]["running_counts"]
    assert counts["sensor_a"] == 13, f"sensor_a count {counts['sensor_a']} != 13"
    assert counts["sensor_b"] == 12, f"sensor_b count {counts['sensor_b']} != 12"
    assert counts["sensor_c"] == 8, f"sensor_c count {counts['sensor_c']} != 8"
    assert counts["sensor_d"] == 8, f"sensor_d count {counts['sensor_d']} != 8"


def test_running_totals_exact():
    """Running totals must match expected values after correct dedup and windowing."""
    report = get_report()
    totals = report["accumulator_state"]["running_totals"]
    assert abs(totals["sensor_a"] - 347.8) < 0.01, (
        f"sensor_a total {totals['sensor_a']} != 347.8"
    )
    assert abs(totals["sensor_b"] - 255.3) < 0.01, (
        f"sensor_b total {totals['sensor_b']} != 255.3"
    )
    assert abs(totals["sensor_c"] - 269.2) < 0.01, (
        f"sensor_c total {totals['sensor_c']} != 269.2"
    )
    assert abs(totals["sensor_d"] - 119.5) < 0.01, (
        f"sensor_d total {totals['sensor_d']} != 119.5"
    )


def test_total_events_across_windows():
    """Sum of window events equals processed count, which must be 41."""
    report = get_report()
    window_total = sum(w["event_count"] for w in report["windows"])
    assert window_total == report["total_events_processed"], (
        f"Window event total {window_total} != processed {report['total_events_processed']}"
    )
    assert window_total == 41, f"Total events across windows {window_total} != 41"
