#!/bin/bash

# Telemetry Batch Reconciler - Fix all pipeline bugs
# Debugging approach: fix each module's logic error

cd "$(dirname "$0")/../environment" || exit 1

echo "=== Fixing telemetry batch reconciler pipeline ==="

# Fix 1: deduplicator.py - uses event_id instead of correlation_id as dedup key
echo "Fixing deduplicator: wrong dedup key (event_id -> correlation_id)..."
sed -i 's/key = event\["event_id"\]/key = event["correlation_id"]/' runtime/deduplicator.py

# Fix 2: sorter.py - only sorts by timestamp, needs stable multi-key sort
echo "Fixing sorter: adding secondary and tertiary sort keys..."
sed -i 's/return sorted(events, key=lambda e: e\["timestamp"\])/return sorted(events, key=lambda e: (e["timestamp"], e["source"], e["event_id"]))/' runtime/sorter.py

# Fix 3: windower.py - boundary events assigned to wrong window
# Events at exact boundary should go to the NEW window, not the previous one
echo "Fixing windower: removing off-by-one boundary assignment..."
python3 << 'PYEOF'
with open("runtime/windower.py", "r") as f:
    content = f.read()

# Replace the buggy boundary logic
old = """        if offset > 0 and offset % window_size_sec == 0:
            window_idx = (offset // window_size_sec) - 1
        else:
            window_idx = offset // window_size_sec"""

new = """        window_idx = offset // window_size_sec"""

content = content.replace(old, new)

with open("runtime/windower.py", "w") as f:
    f.write(content)
PYEOF

# Fix 4: accumulator.py - gap logic is inverted
# gap_count == 1 should carry forward; gap_count > 1 should reset
echo "Fixing accumulator: inverting gap detection logic..."
python3 << 'PYEOF'
with open("runtime/accumulator.py", "r") as f:
    content = f.read()

old = """            else:
                self.gap_count[src] += 1
                if self.gap_count[src] == 1:
                    self.running_totals[src] = 0.0
                    self.running_counts[src] = 0"""

new = """            else:
                self.gap_count[src] += 1
                if self.gap_count[src] > 1:
                    self.running_totals[src] = 0.0
                    self.running_counts[src] = 0"""

content = content.replace(old, new)

with open("runtime/accumulator.py", "w") as f:
    f.write(content)
PYEOF

# Fix 5: aggregator.py - integer division when total is whole number
echo "Fixing aggregator: removing integer division path..."
python3 << 'PYEOF'
with open("runtime/aggregator.py", "r") as f:
    content = f.read()

old = """            if total == int(total):
                avg = int(total) // count
            else:
                avg = total / count"""

new = """            avg = total / count"""

content = content.replace(old, new)

with open("runtime/aggregator.py", "w") as f:
    f.write(content)
PYEOF

# Run the pipeline to generate correct output
echo ""
echo "=== Running fixed pipeline ==="
python3 -m runtime.run_pipeline

echo ""
echo "=== Done. Outputs written to environment/output/ ==="
