#!/bin/bash
# Solve script for distributed retry queue processor debugging task.
# Applies fixes to all four buggy modules and regenerates output.

cd /app
python3 /solution/repair_retry_processor.py

REPAIR_STATUS=$?
if [ $REPAIR_STATUS -ne 0 ]; then
    echo "ERROR: Repair script failed with status $REPAIR_STATUS"
    exit 1
fi

# Verify output was generated
OUTPUT_FILE="/app/runtime/output/retry_summary.json"
if [ -f "$OUTPUT_FILE" ]; then
    echo ""
    echo "=== Output verification ==="
    echo "Output file exists: $OUTPUT_FILE"
    echo "File size: $(wc -c < "$OUTPUT_FILE") bytes"
    echo ""
    echo "Summary preview:"
    python3 -c "
import json
with open('$OUTPUT_FILE', 'r') as f:
    s = json.load(f)
print(f\"  Total events processed: {s['total_events_processed']}\")
print(f\"  Unique jobs: {s['unique_jobs']}\")
print(f\"  Total dropped: {s['total_dropped']}\")
print(f\"  Final queue size: {s['final_queue_size']}\")
print(f\"  Windows processed: {s['windows_processed']}\")
print(f\"  Queue order (first 5): {s['final_queue_order'][:5]}\")
"
    echo ""
    echo "=== Repair successful ==="
else
    echo "ERROR: Output file not generated"
    exit 1
fi
