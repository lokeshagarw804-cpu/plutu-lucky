#!/bin/bash
# Solve script for distributed retry queue processor debugging task.
# Applies fixes to all four buggy modules and regenerates output.

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TASK_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
RUNTIME_DIR="$TASK_DIR/environment/runtime"

echo "=== Distributed Retry Queue Processor - Repair ==="
echo "Runtime directory: $RUNTIME_DIR"

# Verify runtime directory exists
if [ ! -d "$RUNTIME_DIR" ]; then
    echo "ERROR: Runtime directory not found"
    exit 1
fi

# Run the repair script
cd "$SCRIPT_DIR"
python3 repair_retry_processor.py

REPAIR_STATUS=$?
if [ $REPAIR_STATUS -ne 0 ]; then
    echo "ERROR: Repair script failed with status $REPAIR_STATUS"
    echo "Attempting manual fix..."
    
    # Fallback: run processor directly if repair script had import issues
    cd "$RUNTIME_DIR"
    python3 run_processor.py
fi

# Verify output was generated
OUTPUT_FILE="$RUNTIME_DIR/output/retry_summary.json"
if [ -f "$OUTPUT_FILE" ]; then
    echo ""
    echo "=== Output verification ==="
    echo "Output file exists: $OUTPUT_FILE"
    echo "File size: $(wc -c < "$OUTPUT_FILE") bytes"
    echo ""
    echo "Summary preview:"
    python3 -c "
import json
with open('$OUTPUT_FILE', 'r') as f:
    s = json.load(f)
print(f\"  Total events processed: {s['total_events_processed']}\")
print(f\"  Unique jobs: {s['unique_jobs']}\")
print(f\"  Total dropped: {s['total_dropped']}\")
print(f\"  Final queue size: {s['final_queue_size']}\")
print(f\"  Windows processed: {s['windows_processed']}\")
print(f\"  Queue order (first 5): {s['final_queue_order'][:5]}\")
"
    echo ""
    echo "=== Repair successful ==="
else
    echo "ERROR: Output file not generated"
    exit 1
fi
