#!/bin/bash
cd /app
python3 /solution/repair_retry_processor.py
