#!/usr/bin/env python3
"""
Repair script for the distributed retry queue processor.
Fixes all four interacting bugs:
1. backoff_calculator.py: off-by-one in exponent (attempt vs attempt-1)
2. queue_state.py: unstable sort (missing job_id secondary key), missing duplicate check, mark_completed doesn't remove from queue
3. dedup_tracker.py: boundary condition (< vs <=), stale entry suppressing new-window events
4. retry_processor.py: pre-increment retry count before max check, no window-scoped reset
"""
import os
import sys
import json


def fix_backoff_calculator(runtime_dir):
    """Fix the off-by-one exponent and jitter application."""
    filepath = os.path.join(runtime_dir, "backoff_calculator.py")
    
    content = '''"""
Exponential backoff calculator with jitter.
"""
import random


def calculate_backoff(attempt, base_delay_ms, max_delay_ms, multiplier, jitter_factor, seed=None):
    """
    Calculate backoff delay for a given attempt number.
    First attempt uses base_delay, subsequent attempts multiply.
    Jitter is applied as additive random offset.
    """
    if seed is not None:
        random.seed(seed)
    
    # Fix: use (attempt - 1) so first retry gets base_delay * multiplier^0 = base_delay
    exponent = max(0, attempt - 1)
    delay = base_delay_ms * (multiplier ** exponent)
    
    # Fix: jitter applied as additive offset, not multiplicative
    jitter = random.random() * jitter_factor * base_delay_ms
    delay = delay + jitter
    
    if delay > max_delay_ms:
        delay = max_delay_ms
    
    return round(delay, 2)


def calculate_total_backoff(attempts_made, base_delay_ms, max_delay_ms, multiplier, jitter_factor, seed=None):
    """
    Calculate sum of all backoff delays up to attempts_made.
    """
    total = 0.0
    for i in range(attempts_made):
        total += calculate_backoff(i, base_delay_ms, max_delay_ms, multiplier, jitter_factor, seed=seed)
    return round(total, 2)
'''
    
    with open(filepath, 'w') as f:
        f.write(content)
    print(f"  Fixed: backoff_calculator.py")


def fix_queue_state(runtime_dir):
    """Fix sort stability, duplicate prevention, and mark_completed cleanup."""
    filepath = os.path.join(runtime_dir, "queue_state.py")
    
    content = '''"""
Ordered queue state management for retry jobs.
"""


class RetryQueue:
    """
    Maintains ordered queue of jobs pending retry.
    Ensures stable sort by (timestamp, job_id) and prevents duplicates.
    """
    
    def __init__(self):
        self.queue = []
        self.completed = set()
    
    def enqueue(self, job_id, timestamp, attempt, priority=0):
        """Add a job to the retry queue. Prevents duplicate entries."""
        if job_id in self.completed:
            return False
        
        # Fix: check for existing entry with same job_id and update it
        for i, entry in enumerate(self.queue):
            if entry["job_id"] == job_id:
                self.queue[i] = {
                    "job_id": job_id,
                    "timestamp": timestamp,
                    "attempt": attempt,
                    "priority": priority
                }
                return True
        
        entry = {
            "job_id": job_id,
            "timestamp": timestamp,
            "attempt": attempt,
            "priority": priority
        }
        self.queue.append(entry)
        return True
    
    def sort_queue(self):
        """
        Sort queue by timestamp (ascending), then by job_id for stable ordering.
        """
        self.queue.sort(key=lambda x: (x["timestamp"], x["job_id"]))
    
    def dequeue(self, count=None):
        """Remove and return top N items from sorted queue."""
        self.sort_queue()
        if count is None:
            count = len(self.queue)
        
        result = self.queue[:count]
        self.queue = self.queue[count:]
        return result
    
    def mark_completed(self, job_id):
        """Mark a job as completed and remove from queue."""
        self.completed.add(job_id)
        self.queue = [e for e in self.queue if e["job_id"] != job_id]
    
    def remove_job(self, job_id):
        """Remove all entries for a job from the queue."""
        self.queue = [e for e in self.queue if e["job_id"] != job_id]
    
    def get_queue_size(self):
        """Return current queue size."""
        return len(self.queue)
    
    def get_pending_jobs(self):
        """Return list of job_ids currently in queue."""
        return [e["job_id"] for e in self.queue]
    
    def has_job(self, job_id):
        """Check if job exists in queue."""
        return any(e["job_id"] == job_id for e in self.queue)
'''
    
    with open(filepath, 'w') as f:
        f.write(content)
    print(f"  Fixed: queue_state.py")


def fix_dedup_tracker(runtime_dir):
    """Fix boundary condition and stale entry suppression."""
    filepath = os.path.join(runtime_dir, "dedup_tracker.py")
    
    content = '''"""
Deduplication tracker for retry events within time windows.
"""


class DedupTracker:
    """
    Tracks which job events have been seen within a deduplication window.
    Properly handles window boundaries and clears stale state.
    """
    
    def __init__(self, dedup_window_sec):
        self.dedup_window_sec = dedup_window_sec
        self.seen = {}
        self.window_start = None
    
    def is_duplicate(self, job_id, timestamp):
        """
        Check if this job event is a duplicate within the current dedup window.
        Returns True if duplicate (should be suppressed), False if new.
        """
        if self.window_start is None:
            self.window_start = timestamp
        
        # Fix: use <= for boundary check
        if timestamp - self.window_start <= self.dedup_window_sec:
            if job_id in self.seen:
                timestamps = self.seen[job_id]
                for ts in timestamps:
                    if abs(ts - timestamp) < self.dedup_window_sec:
                        return True
                self.seen[job_id].append(timestamp)
                return False
            else:
                self.seen[job_id] = [timestamp]
                return False
        else:
            # New window - Fix: fully clear old state
            self.window_start = timestamp
            self.seen = {}
            self.seen[job_id] = [timestamp]
            return False
    
    def get_dedup_count(self):
        """Return total number of tracked entries."""
        return sum(len(v) for v in self.seen.values())
    
    def reset(self):
        """Full reset."""
        self.seen = {}
        self.window_start = None
'''
    
    with open(filepath, 'w') as f:
        f.write(content)
    print(f"  Fixed: dedup_tracker.py")


def fix_retry_processor(runtime_dir):
    """Fix pre-increment, window rollover, and summary aggregation bugs."""
    filepath = os.path.join(runtime_dir, "retry_processor.py")
    
    content = '''"""
Main retry queue processor.
Reads job events, applies retry logic, and produces summaries.
"""
import json
import os

from runtime.backoff_calculator import calculate_backoff, calculate_total_backoff
from runtime.dedup_tracker import DedupTracker
from runtime.queue_state import RetryQueue


class RetryProcessor:
    """
    Processes job retry events from worker nodes.
    Fixed: proper attempt counting, window rollover, and summary generation.
    """
    
    def __init__(self, config_path="config.json"):
        with open(config_path, 'r') as f:
            self.config = json.load(f)
        
        policy = self.config['retry_policy']
        self.max_attempts = policy['max_attempts']
        self.base_delay_ms = policy['base_delay_ms']
        self.max_delay_ms = policy['max_delay_ms']
        self.multiplier = policy['backoff_multiplier']
        self.jitter_factor = policy['jitter_factor']
        self.dedup_window_sec = policy['dedup_window_sec']
        self.window_size_sec = policy['window_size_sec']
        self.overflow_policy = policy['overflow_policy']
        
        self.dedup = DedupTracker(self.dedup_window_sec)
        self.queue = RetryQueue()
        
        self.retry_counts = {}
        self.retry_history = []
        self.dropped_jobs = []
        self.completed_jobs = []
        self.window_stats = []
        self.current_window = 0
        self.window_start_time = None
        self.deduplicated_count = 0
    
    def process_event(self, event):
        """Process a single job retry event."""
        job_id = event['job_id']
        timestamp = event['timestamp']
        worker_id = event.get('worker_id', 'unknown')
        error_type = event.get('error_type', 'unknown')
        
        if self.window_start_time is None:
            self.window_start_time = timestamp
        
        if timestamp - self.window_start_time >= self.window_size_sec:
            self._rollover_window(timestamp)
        
        is_dup = self.dedup.is_duplicate(job_id, timestamp)
        if is_dup:
            self.deduplicated_count += 1
            return {"job_id": job_id, "action": "deduplicated", "timestamp": timestamp}
        
        if job_id not in self.retry_counts:
            self.retry_counts[job_id] = 0
        
        # Fix: check max attempts BEFORE incrementing
        if self.retry_counts[job_id] >= self.max_attempts:
            self.dropped_jobs.append({
                "job_id": job_id,
                "final_attempt": self.retry_counts[job_id],
                "timestamp": timestamp,
                "reason": "max_attempts_exceeded"
            })
            self.queue.mark_completed(job_id)
            return {"job_id": job_id, "action": "dropped", "attempt": self.retry_counts[job_id]}
        
        self.retry_counts[job_id] += 1
        current_attempt = self.retry_counts[job_id]
        
        self.retry_history.append({
            "job_id": job_id,
            "attempt": current_attempt,
            "timestamp": timestamp,
            "worker_id": worker_id,
            "error_type": error_type,
            "window": self.current_window
        })
        
        delay = calculate_backoff(
            current_attempt, self.base_delay_ms, self.max_delay_ms,
            self.multiplier, self.jitter_factor, seed=hash(job_id) % 10000
        )
        
        retry_time = timestamp + (delay / 1000.0)
        self.queue.enqueue(job_id, retry_time, current_attempt, priority=current_attempt)
        
        return {
            "job_id": job_id,
            "action": "retrying",
            "attempt": current_attempt,
            "next_retry_at": retry_time,
            "delay_ms": delay
        }
    
    def _rollover_window(self, new_timestamp):
        """Handle window rollover. Fix: resets per-job retry counts."""
        self.window_stats.append({
            "window": self.current_window,
            "start": self.window_start_time,
            "end": new_timestamp,
            "events_processed": len([h for h in self.retry_history if h['window'] == self.current_window]),
            "queue_size": self.queue.get_queue_size()
        })
        
        self.current_window += 1
        self.window_start_time = new_timestamp
        
        # Fix: reset retry counts on window rollover
        self.retry_counts = {}
    
    def process_all_events(self, events):
        """Process a list of events in order."""
        results = []
        for event in events:
            result = self.process_event(event)
            results.append(result)
        return results
    
    def generate_summary(self):
        """Generate final retry summary using only validated history."""
        final_queue = self.queue.dequeue()
        
        job_summaries = {}
        for entry in self.retry_history:
            jid = entry['job_id']
            if jid not in job_summaries:
                job_summaries[jid] = {
                    "job_id": jid,
                    "total_attempts": 0,
                    "first_seen": entry['timestamp'],
                    "last_seen": entry['timestamp'],
                    "workers": set(),
                    "error_types": set(),
                    "windows_spanned": set()
                }
            job_summaries[jid]["total_attempts"] += 1
            job_summaries[jid]["last_seen"] = max(job_summaries[jid]["last_seen"], entry['timestamp'])
            job_summaries[jid]["workers"].add(entry['worker_id'])
            job_summaries[jid]["error_types"].add(entry['error_type'])
            job_summaries[jid]["windows_spanned"].add(entry['window'])
        
        for jid in job_summaries:
            job_summaries[jid]["workers"] = sorted(list(job_summaries[jid]["workers"]))
            job_summaries[jid]["error_types"] = sorted(list(job_summaries[jid]["error_types"]))
            job_summaries[jid]["windows_spanned"] = sorted(list(job_summaries[jid]["windows_spanned"]))
        
        summary = {
            "total_events_processed": len(self.retry_history),
            "unique_jobs": len(job_summaries),
            "total_dropped": len(self.dropped_jobs),
            "total_completed": len(self.completed_jobs),
            "total_deduplicated": self.deduplicated_count,
            "final_queue_size": len(final_queue),
            "final_queue_order": [e["job_id"] for e in final_queue],
            "windows_processed": self.current_window + 1,
            "window_stats": self.window_stats,
            "job_summaries": job_summaries,
            "dropped_jobs": self.dropped_jobs
        }
        
        return summary
'''
    
    with open(filepath, 'w') as f:
        f.write(content)
    print(f"  Fixed: retry_processor.py")


def main():
    # In Docker container, runtime is at /app/runtime
    # Fallback to relative path for local development
    runtime_dir = "/app/runtime"
    if not os.path.isdir(runtime_dir):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        runtime_dir = os.path.join(script_dir, "..", "environment", "runtime")
        runtime_dir = os.path.abspath(runtime_dir)
    
    print(f"Repairing files in: {runtime_dir}")
    
    if not os.path.isdir(runtime_dir):
        print(f"Error: runtime directory not found at {runtime_dir}")
        sys.exit(1)
    
    fix_backoff_calculator(runtime_dir)
    fix_queue_state(runtime_dir)
    fix_dedup_tracker(runtime_dir)
    fix_retry_processor(runtime_dir)
    
    print("\nAll fixes applied. Running processor...")
    
    # Run the processor to generate correct output
    os.chdir("/app")
    
    # Clear cached modules
    for mod_name in list(sys.modules.keys()):
        if mod_name in ('runtime.backoff_calculator', 'runtime.queue_state', 
                        'runtime.dedup_tracker', 'runtime.retry_processor', 
                        'runtime.run_processor', 'runtime'):
            del sys.modules[mod_name]
    
    from runtime.run_processor import main as run_main
    run_main()
    
    print("\nRepair complete.")


if __name__ == "__main__":
    main()
