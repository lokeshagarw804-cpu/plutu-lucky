# Distributed Retry Queue Processor — Bug Report

We have a retry queue processor that handles failed job events from multiple worker nodes. Each job has a retry policy with exponential backoff, max attempts, and deduplication windows. The processor reads events from `environment/runtime/data/`, applies retry logic, and writes aggregated summaries to `environment/runtime/output/`.

## Symptoms

After the last deploy, the output summaries are wrong:

- Retry counts for some jobs exceed the configured max attempts
- Jobs that should be deduplicated within the same retry window appear multiple times
- The ordering of retried jobs in the output queue is non-deterministic when it should be stable (ordered by first-seen timestamp, then job ID)
- Rollover behavior at the retry window boundary is incorrect — jobs crossing a window boundary get double-counted

## What to fix

The processor logic lives in `environment/runtime/`. Key files:

- `retry_processor.py` — main processing loop
- `backoff_calculator.py` — exponential backoff with jitter
- `dedup_tracker.py` — deduplication window logic
- `queue_state.py` — ordered queue state management
- `config.json` — retry policy configuration

Run the processor:

```bash
cd environment/runtime && python run_processor.py
```

Output goes to `environment/runtime/output/retry_summary.json`.

Fix the bugs so that retry counts respect max attempts, deduplication works within windows, ordering is deterministic, and window rollover counting is correct.
