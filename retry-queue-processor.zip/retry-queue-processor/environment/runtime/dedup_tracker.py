"""
Deduplication tracker for retry events within time windows.
"""


class DedupTracker:
    """
    Tracks which job events have been seen within a deduplication window.
    Properly handles window boundaries and clears stale state.
    """
    
    def __init__(self, dedup_window_sec):
        self.dedup_window_sec = dedup_window_sec
        self.seen = {}
        self.window_start = None
    
    def is_duplicate(self, job_id, timestamp):
        """
        Check if this job event is a duplicate within the current dedup window.
        Returns True if duplicate (should be suppressed), False if new.
        """
        if self.window_start is None:
            self.window_start = timestamp
        
        # Fix: use <= for boundary check
        if timestamp - self.window_start <= self.dedup_window_sec:
            if job_id in self.seen:
                timestamps = self.seen[job_id]
                for ts in timestamps:
                    if abs(ts - timestamp) < self.dedup_window_sec:
                        return True
                self.seen[job_id].append(timestamp)
                return False
            else:
                self.seen[job_id] = [timestamp]
                return False
        else:
            # New window - Fix: fully clear old state
            self.window_start = timestamp
            self.seen = {}
            self.seen[job_id] = [timestamp]
            return False
    
    def get_dedup_count(self):
        """Return total number of tracked entries."""
        return sum(len(v) for v in self.seen.values())
    
    def reset(self):
        """Full reset."""
        self.seen = {}
        self.window_start = None
