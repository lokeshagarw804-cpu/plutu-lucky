"""
Deduplication tracker for retry events within time windows.
"""


class DedupTracker:
    """
    Tracks which job events have been seen within a deduplication window.
    
    BUG 1: Window boundary check uses < instead of <= causing events exactly at
    the boundary to be considered "new window" and not deduplicated.
    
    BUG 2: When a job crosses a window boundary, the tracker doesn't clear
    the previous window's state, causing stale entries to persist and
    incorrectly suppress retries in the new window.
    """
    
    def __init__(self, dedup_window_sec):
        self.dedup_window_sec = dedup_window_sec
        self.seen = {}  # job_id -> list of timestamps
        self.window_start = None
    
    def is_duplicate(self, job_id, timestamp):
        """
        Check if this job event is a duplicate within the current dedup window.
        Returns True if duplicate (should be suppressed), False if new.
        """
        if self.window_start is None:
            self.window_start = timestamp
        
        # Bug: uses < instead of <= for boundary check
        # Events exactly at window_start + dedup_window_sec are treated as new window
        if timestamp - self.window_start < self.dedup_window_sec:
            # Within current window
            if job_id in self.seen:
                timestamps = self.seen[job_id]
                # Check if we've seen this job in this window
                for ts in timestamps:
                    if abs(ts - timestamp) < self.dedup_window_sec:
                        return True
                self.seen[job_id].append(timestamp)
                return False
            else:
                self.seen[job_id] = [timestamp]
                return False
        else:
            # New window — BUG: doesn't fully clear old state
            # Only updates window_start but keeps stale entries
            self.window_start = timestamp
            # Bug: should do self.seen = {} here but instead only removes
            # entries older than 2 windows ago (too lenient)
            stale_cutoff = timestamp - (self.dedup_window_sec * 2)
            keys_to_remove = []
            for jid, timestamps in self.seen.items():
                self.seen[jid] = [t for t in timestamps if t > stale_cutoff]
                if not self.seen[jid]:
                    keys_to_remove.append(jid)
            for k in keys_to_remove:
                del self.seen[k]
            
            if job_id in self.seen:
                # Stale entry still present — incorrectly reports duplicate
                self.seen[job_id].append(timestamp)
                return True  # Bug: should be False for new window
            else:
                self.seen[job_id] = [timestamp]
                return False
    
    def get_dedup_count(self):
        """Return total number of tracked entries."""
        return sum(len(v) for v in self.seen.values())
    
    def reset(self):
        """Full reset."""
        self.seen = {}
        self.window_start = None
