"""
Main retry queue processor.
Reads job events, applies retry logic, and produces summaries.
"""
import json
import os

from backoff_calculator import calculate_backoff, calculate_total_backoff
from dedup_tracker import DedupTracker
from queue_state import RetryQueue


class RetryProcessor:
    """
    Processes job retry events from worker nodes.
    Fixed: proper attempt counting, window rollover, and summary generation.
    """
    
    def __init__(self, config_path="config.json"):
        with open(config_path, 'r') as f:
            self.config = json.load(f)
        
        policy = self.config['retry_policy']
        self.max_attempts = policy['max_attempts']
        self.base_delay_ms = policy['base_delay_ms']
        self.max_delay_ms = policy['max_delay_ms']
        self.multiplier = policy['backoff_multiplier']
        self.jitter_factor = policy['jitter_factor']
        self.dedup_window_sec = policy['dedup_window_sec']
        self.window_size_sec = policy['window_size_sec']
        self.overflow_policy = policy['overflow_policy']
        
        self.dedup = DedupTracker(self.dedup_window_sec)
        self.queue = RetryQueue()
        
        self.retry_counts = {}
        self.retry_history = []
        self.dropped_jobs = []
        self.completed_jobs = []
        self.window_stats = []
        self.current_window = 0
        self.window_start_time = None
        self.deduplicated_count = 0
    
    def process_event(self, event):
        """Process a single job retry event."""
        job_id = event['job_id']
        timestamp = event['timestamp']
        worker_id = event.get('worker_id', 'unknown')
        error_type = event.get('error_type', 'unknown')
        
        if self.window_start_time is None:
            self.window_start_time = timestamp
        
        if timestamp - self.window_start_time >= self.window_size_sec:
            self._rollover_window(timestamp)
        
        is_dup = self.dedup.is_duplicate(job_id, timestamp)
        if is_dup:
            self.deduplicated_count += 1
            return {"job_id": job_id, "action": "deduplicated", "timestamp": timestamp}
        
        if job_id not in self.retry_counts:
            self.retry_counts[job_id] = 0
        
        # Fix: check max attempts BEFORE incrementing
        if self.retry_counts[job_id] >= self.max_attempts:
            self.dropped_jobs.append({
                "job_id": job_id,
                "final_attempt": self.retry_counts[job_id],
                "timestamp": timestamp,
                "reason": "max_attempts_exceeded"
            })
            self.queue.mark_completed(job_id)
            return {"job_id": job_id, "action": "dropped", "attempt": self.retry_counts[job_id]}
        
        self.retry_counts[job_id] += 1
        current_attempt = self.retry_counts[job_id]
        
        self.retry_history.append({
            "job_id": job_id,
            "attempt": current_attempt,
            "timestamp": timestamp,
            "worker_id": worker_id,
            "error_type": error_type,
            "window": self.current_window
        })
        
        delay = calculate_backoff(
            current_attempt, self.base_delay_ms, self.max_delay_ms,
            self.multiplier, self.jitter_factor, seed=hash(job_id) % 10000
        )
        
        retry_time = timestamp + (delay / 1000.0)
        self.queue.enqueue(job_id, retry_time, current_attempt, priority=current_attempt)
        
        return {
            "job_id": job_id,
            "action": "retrying",
            "attempt": current_attempt,
            "next_retry_at": retry_time,
            "delay_ms": delay
        }
    
    def _rollover_window(self, new_timestamp):
        """Handle window rollover. Fix: resets per-job retry counts."""
        self.window_stats.append({
            "window": self.current_window,
            "start": self.window_start_time,
            "end": new_timestamp,
            "events_processed": len([h for h in self.retry_history if h['window'] == self.current_window]),
            "queue_size": self.queue.get_queue_size()
        })
        
        self.current_window += 1
        self.window_start_time = new_timestamp
        
        # Fix: reset retry counts on window rollover
        self.retry_counts = {}
    
    def process_all_events(self, events):
        """Process a list of events in order."""
        results = []
        for event in events:
            result = self.process_event(event)
            results.append(result)
        return results
    
    def generate_summary(self):
        """Generate final retry summary using only validated history."""
        final_queue = self.queue.dequeue()
        
        job_summaries = {}
        for entry in self.retry_history:
            jid = entry['job_id']
            if jid not in job_summaries:
                job_summaries[jid] = {
                    "job_id": jid,
                    "total_attempts": 0,
                    "first_seen": entry['timestamp'],
                    "last_seen": entry['timestamp'],
                    "workers": set(),
                    "error_types": set(),
                    "windows_spanned": set()
                }
            job_summaries[jid]["total_attempts"] += 1
            job_summaries[jid]["last_seen"] = max(job_summaries[jid]["last_seen"], entry['timestamp'])
            job_summaries[jid]["workers"].add(entry['worker_id'])
            job_summaries[jid]["error_types"].add(entry['error_type'])
            job_summaries[jid]["windows_spanned"].add(entry['window'])
        
        for jid in job_summaries:
            job_summaries[jid]["workers"] = sorted(list(job_summaries[jid]["workers"]))
            job_summaries[jid]["error_types"] = sorted(list(job_summaries[jid]["error_types"]))
            job_summaries[jid]["windows_spanned"] = sorted(list(job_summaries[jid]["windows_spanned"]))
        
        summary = {
            "total_events_processed": len(self.retry_history),
            "unique_jobs": len(job_summaries),
            "total_dropped": len(self.dropped_jobs),
            "total_completed": len(self.completed_jobs),
            "total_deduplicated": self.deduplicated_count,
            "final_queue_size": len(final_queue),
            "final_queue_order": [e["job_id"] for e in final_queue],
            "windows_processed": self.current_window + 1,
            "window_stats": self.window_stats,
            "job_summaries": job_summaries,
            "dropped_jobs": self.dropped_jobs
        }
        
        return summary
