"""
Exponential backoff calculator with jitter.
"""
import random


def calculate_backoff(attempt, base_delay_ms, max_delay_ms, multiplier, jitter_factor, seed=None):
    """
    Calculate backoff delay for a given attempt number.
    First attempt uses base_delay, subsequent attempts multiply.
    Jitter is applied as additive random offset.
    """
    if seed is not None:
        random.seed(seed)
    
    # Fix: use (attempt - 1) so first retry gets base_delay * multiplier^0 = base_delay
    exponent = max(0, attempt - 1)
    delay = base_delay_ms * (multiplier ** exponent)
    
    # Fix: jitter applied as additive offset, not multiplicative
    jitter = random.random() * jitter_factor * base_delay_ms
    delay = delay + jitter
    
    if delay > max_delay_ms:
        delay = max_delay_ms
    
    return round(delay, 2)


def calculate_total_backoff(attempts_made, base_delay_ms, max_delay_ms, multiplier, jitter_factor, seed=None):
    """
    Calculate sum of all backoff delays up to attempts_made.
    """
    total = 0.0
    for i in range(attempts_made):
        total += calculate_backoff(i, base_delay_ms, max_delay_ms, multiplier, jitter_factor, seed=seed)
    return round(total, 2)
