"""
Exponential backoff calculator with jitter.
"""
import random


def calculate_backoff(attempt, base_delay_ms, max_delay_ms, multiplier, jitter_factor, seed=None):
    """
    Calculate backoff delay for a given attempt number.
    
    BUG: Uses attempt directly instead of (attempt - 1) for exponent,
    causing the first retry to already use multiplier^1 instead of base_delay.
    Also, jitter is applied multiplicatively instead of additively.
    """
    if seed is not None:
        random.seed(seed)
    
    # Bug: should be (attempt - 1) for zero-indexed first retry
    delay = base_delay_ms * (multiplier ** attempt)
    
    # Bug: jitter applied as multiplier (1 + jitter) instead of additive random offset
    jitter = 1.0 + (random.random() * jitter_factor)
    delay = delay * jitter
    
    if delay > max_delay_ms:
        delay = max_delay_ms
    
    return round(delay, 2)


def calculate_total_backoff(attempts_made, base_delay_ms, max_delay_ms, multiplier, jitter_factor, seed=None):
    """
    Calculate sum of all backoff delays up to attempts_made.
    """
    total = 0.0
    for i in range(attempts_made):
        total += calculate_backoff(i, base_delay_ms, max_delay_ms, multiplier, jitter_factor, seed=seed)
    return round(total, 2)
