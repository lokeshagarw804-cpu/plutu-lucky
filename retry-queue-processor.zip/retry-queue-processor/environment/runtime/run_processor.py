"""
Entry point for the retry queue processor.
Loads events from data files and produces retry_summary.json.
"""
import json
import os

from runtime.retry_processor import RetryProcessor


def load_events(data_dir="/app/runtime/data"):
    """Load all event files from data directory, sorted by filename."""
    events = []
    if not os.path.exists(data_dir):
        print(f"Error: data directory '{data_dir}' not found")
        return events

    files = sorted([f for f in os.listdir(data_dir) if f.endswith('.json')])
    for fname in files:
        filepath = os.path.join(data_dir, fname)
        with open(filepath, 'r') as f:
            data = json.load(f)
            if isinstance(data, list):
                events.extend(data)
            else:
                events.append(data)

    # Sort events by timestamp for deterministic processing
    events.sort(key=lambda e: (e['timestamp'], e['job_id']))
    return events


def main():
    # Load config and process
    processor = RetryProcessor(config_path="/app/runtime/config.json")
    events = load_events("/app/runtime/data")

    print(f"Loaded {len(events)} events from data/")

    # Process all events
    results = processor.process_all_events(events)

    # Generate summary
    summary = processor.generate_summary()

    # Write output
    output_dir = "/app/runtime/output"
    os.makedirs(output_dir, exist_ok=True)

    output_path = os.path.join(output_dir, "retry_summary.json")
    with open(output_path, 'w') as f:
        json.dump(summary, f, indent=2, default=str)

    print(f"Summary written to {output_path}")
    print(f"  Total events processed: {summary['total_events_processed']}")
    print(f"  Unique jobs: {summary['unique_jobs']}")
    print(f"  Dropped jobs: {summary['total_dropped']}")
    print(f"  Final queue size: {summary['final_queue_size']}")
    print(f"  Windows processed: {summary['windows_processed']}")


if __name__ == "__main__":
    main()
