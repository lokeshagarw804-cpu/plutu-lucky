"""
Ordered queue state management for retry jobs.
"""
from operator import itemgetter


class RetryQueue:
    """
    Maintains ordered queue of jobs pending retry.
    
    BUG 1: Sort is not stable — uses only timestamp for ordering,
    ignoring job_id as tiebreaker. When two jobs have the same timestamp,
    their relative order is non-deterministic.
    
    BUG 2: When removing completed jobs, the queue doesn't preserve
    insertion order for jobs with identical priorities.
    
    BUG 3: The enqueue method doesn't check if a job already exists
    in the queue before adding, potentially creating duplicates that
    the dedup tracker should have caught.
    """
    
    def __init__(self):
        self.queue = []  # list of dicts: {job_id, timestamp, attempt, priority}
        self.completed = set()
    
    def enqueue(self, job_id, timestamp, attempt, priority=0):
        """Add a job to the retry queue."""
        if job_id in self.completed:
            return False
        
        # Bug: doesn't check for existing entry with same job_id
        # This can create duplicate queue entries
        entry = {
            "job_id": job_id,
            "timestamp": timestamp,
            "attempt": attempt,
            "priority": priority
        }
        self.queue.append(entry)
        return True
    
    def sort_queue(self):
        """
        Sort queue by timestamp (ascending), then by job_id for stable ordering.
        BUG: Only sorts by timestamp, not using job_id as secondary key.
        """
        # Bug: should be key=lambda x: (x['timestamp'], x['job_id'])
        self.queue.sort(key=itemgetter('timestamp'))
    
    def dequeue(self, count=None):
        """Remove and return top N items from sorted queue."""
        self.sort_queue()
        if count is None:
            count = len(self.queue)
        
        result = self.queue[:count]
        self.queue = self.queue[count:]
        return result
    
    def mark_completed(self, job_id):
        """Mark a job as completed (no more retries)."""
        self.completed.add(job_id)
        # Bug: doesn't remove existing entries for this job_id from queue
        # They remain and get processed again
    
    def remove_job(self, job_id):
        """Remove all entries for a job from the queue."""
        self.queue = [e for e in self.queue if e["job_id"] != job_id]
    
    def get_queue_size(self):
        """Return current queue size."""
        return len(self.queue)
    
    def get_pending_jobs(self):
        """Return list of job_ids currently in queue."""
        return [e["job_id"] for e in self.queue]
    
    def has_job(self, job_id):
        """Check if job exists in queue."""
        return any(e["job_id"] == job_id for e in self.queue)
