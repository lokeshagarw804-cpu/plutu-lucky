"""
Ordered queue state management for retry jobs.
"""


class RetryQueue:
    """
    Maintains ordered queue of jobs pending retry.
    Ensures stable sort by (timestamp, job_id) and prevents duplicates.
    """
    
    def __init__(self):
        self.queue = []
        self.completed = set()
    
    def enqueue(self, job_id, timestamp, attempt, priority=0):
        """Add a job to the retry queue. Prevents duplicate entries."""
        if job_id in self.completed:
            return False
        
        # Fix: check for existing entry with same job_id and update it
        for i, entry in enumerate(self.queue):
            if entry["job_id"] == job_id:
                self.queue[i] = {
                    "job_id": job_id,
                    "timestamp": timestamp,
                    "attempt": attempt,
                    "priority": priority
                }
                return True
        
        entry = {
            "job_id": job_id,
            "timestamp": timestamp,
            "attempt": attempt,
            "priority": priority
        }
        self.queue.append(entry)
        return True
    
    def sort_queue(self):
        """
        Sort queue by timestamp (ascending), then by job_id for stable ordering.
        """
        self.queue.sort(key=lambda x: (x["timestamp"], x["job_id"]))
    
    def dequeue(self, count=None):
        """Remove and return top N items from sorted queue."""
        self.sort_queue()
        if count is None:
            count = len(self.queue)
        
        result = self.queue[:count]
        self.queue = self.queue[count:]
        return result
    
    def mark_completed(self, job_id):
        """Mark a job as completed and remove from queue."""
        self.completed.add(job_id)
        self.queue = [e for e in self.queue if e["job_id"] != job_id]
    
    def remove_job(self, job_id):
        """Remove all entries for a job from the queue."""
        self.queue = [e for e in self.queue if e["job_id"] != job_id]
    
    def get_queue_size(self):
        """Return current queue size."""
        return len(self.queue)
    
    def get_pending_jobs(self):
        """Return list of job_ids currently in queue."""
        return [e["job_id"] for e in self.queue]
    
    def has_job(self, job_id):
        """Check if job exists in queue."""
        return any(e["job_id"] == job_id for e in self.queue)
