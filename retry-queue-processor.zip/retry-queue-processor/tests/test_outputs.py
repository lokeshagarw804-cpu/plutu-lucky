"""
Test suite for retry queue processor output validation.
Verifies correct behavior of the distributed retry queue processor
after bug fixes have been applied.
"""
import json
import hashlib
import os
import sys

# Ensure we can import from runtime
sys.path.insert(0, "/app/runtime")

OUTPUT_PATH = "/app/runtime/output/retry_summary.json"
DATA_DIR = "/app/runtime/data"


def load_summary():
    """Load the retry summary output file."""
    assert os.path.exists(OUTPUT_PATH), f"Output file not found: {OUTPUT_PATH}"
    with open(OUTPUT_PATH, 'r') as f:
        return json.load(f)


def get_data_hash():
    """Compute hash of all data files to detect tampering."""
    hasher = hashlib.sha256()
    data_files = sorted(os.listdir(DATA_DIR))
    for fname in data_files:
        fpath = os.path.join(DATA_DIR, fname)
        with open(fpath, 'rb') as f:
            hasher.update(f.read())
    return hasher.hexdigest()


# --- Anti-cheat: verify data integrity ---

def test_data_files_integrity():
    """Verify that input data files have not been modified."""
    expected_hash = "3d9cb6b1c45d0ac325bfdefe5901afbd16a345d586539f300a17b435b1d9a358"
    actual_hash = get_data_hash()
    assert actual_hash == expected_hash, "Input data files have been tampered with"


# --- Basic aggregation tests (agents typically pass these) ---

def test_output_file_exists_and_has_dedup_field():
    """Verify the output file was generated and contains required fields."""
    assert os.path.exists(OUTPUT_PATH), "retry_summary.json not found"
    summary = load_summary()
    required_fields = ["total_events_processed", "unique_jobs", "total_dropped",
                       "total_deduplicated", "final_queue_size", "final_queue_order",
                       "windows_processed", "window_stats", "job_summaries"]
    for field in required_fields:
        assert field in summary, f"Required field '{field}' missing from summary"


def test_unique_jobs_count_and_queue_match():
    """Verify unique jobs count matches final queue entries."""
    summary = load_summary()
    assert summary["unique_jobs"] == 22, f"Expected 22 unique jobs, got {summary['unique_jobs']}"
    # Queue should contain exactly one entry per unique job
    assert summary["final_queue_size"] == summary["unique_jobs"], \
        f"Queue size ({summary['final_queue_size']}) should equal unique jobs ({summary['unique_jobs']})"


def test_windows_processed_with_correct_boundaries():
    """Verify correct number of processing windows with proper boundary handling."""
    summary = load_summary()
    assert summary["windows_processed"] == 3, f"Expected 3 windows, got {summary['windows_processed']}"
    # First window should start at 1000.0
    assert summary["window_stats"][0]["start"] == 1000.0
    # Total events across all windows + final window should equal total_events_processed
    total_window_events = sum(w["events_processed"] for w in summary["window_stats"])
    # The final window's events are not in window_stats (only completed windows are)
    # So remaining events are in the final (current) window
    remaining = summary["total_events_processed"] - total_window_events
    assert remaining == 12, \
        f"Final window should have 12 events, got {remaining}"


def test_no_jobs_dropped_with_window_reset():
    """Verify no jobs exceed max attempts with correct window-scoped counting."""
    summary = load_summary()
    assert summary["total_dropped"] == 0, f"Expected 0 dropped jobs, got {summary['total_dropped']}"
    # Verify job_015 spans 2 windows correctly with window-scoped retry resets
    job_015 = summary["job_summaries"]["job_015"]
    assert job_015["total_attempts"] == 3, \
        f"job_015 should have 3 total attempts with window resets, got {job_015['total_attempts']}"
    assert sorted(job_015["workers"]) == ["node_d", "node_e"], \
        f"job_015 workers should be ['node_d', 'node_e'], got {job_015['workers']}"


def test_total_events_processed():
    """Verify correct total events (excluding proper deduplication)."""
    summary = load_summary()
    # With correct dedup and window-scoped counting: 39 events
    assert summary["total_events_processed"] == 39, \
        f"Expected 39 total events processed, got {summary['total_events_processed']}"


def test_final_queue_has_no_duplicates():
    """Verify no job appears more than once in the final queue."""
    summary = load_summary()
    queue_order = summary["final_queue_order"]
    assert len(queue_order) == len(set(queue_order)), \
        f"Final queue contains duplicate entries: {[x for x in queue_order if queue_order.count(x) > 1]}"


def test_final_queue_size():
    """Verify final queue has exactly one entry per unique job."""
    summary = load_summary()
    assert summary["final_queue_size"] == 22, \
        f"Expected final queue size 22, got {summary['final_queue_size']}"


# --- Ordering tests (hidden semantic edge cases) ---

def test_queue_ordering_deterministic():
    """Verify queue is sorted by (timestamp, job_id) for deterministic ordering."""
    summary = load_summary()
    queue_order = summary["final_queue_order"]
    # These are the expected first 5 jobs based on correct (timestamp, job_id) sort
    expected_prefix = ["job_004", "job_008", "job_005", "job_009", "job_007"]
    assert queue_order[:5] == expected_prefix, \
        f"Queue ordering incorrect. Expected prefix {expected_prefix}, got {queue_order[:5]}"


def test_queue_ordering_tail():
    """Verify the tail of the queue is correctly ordered."""
    summary = load_summary()
    queue_order = summary["final_queue_order"]
    # Last 5 jobs in correct order
    expected_tail = ["job_002", "job_021", "job_003", "job_022"]
    assert queue_order[-4:] == expected_tail, \
        f"Queue tail ordering incorrect. Expected {expected_tail}, got {queue_order[-4:]}"


def test_same_timestamp_ordering():
    """Verify that jobs with identical timestamps are ordered by job_id."""
    summary = load_summary()
    queue_order = summary["final_queue_order"]
    # job_010 and job_011 both first-seen at 1060.0, same window
    # Their queue positions should have job_010 before job_011 due to ID sort
    idx_010 = queue_order.index("job_010")
    idx_011 = queue_order.index("job_011")
    assert idx_010 < idx_011, \
        f"job_010 (idx={idx_010}) should come before job_011 (idx={idx_011}) due to stable sort on job_id"


# --- Deduplication tests (hidden semantic edge cases) ---

def test_deduplication_count():
    """Verify correct number of events were deduplicated."""
    summary = load_summary()
    assert "total_deduplicated" in summary, "Summary missing total_deduplicated field"
    assert summary["total_deduplicated"] == 11, \
        f"Expected 11 deduplicated events, got {summary['total_deduplicated']}"


def test_window_boundary_dedup():
    """Verify events at exact window boundary are handled correctly."""
    summary = load_summary()
    # job_001 should have exactly 3 valid attempts total
    job_001 = summary["job_summaries"]["job_001"]
    assert job_001["total_attempts"] == 3, \
        f"job_001 should have 3 total attempts, got {job_001['total_attempts']}"
    # job_001 workers should include node_a and node_e (from windows 0 and 2)
    assert sorted(job_001["workers"]) == ["node_a", "node_e"], \
        f"job_001 workers should be ['node_a', 'node_e'], got {job_001['workers']}"
    # job_015 should span windows [1, 2] (events at 1090, 1105, 1120, 1140)
    # with proper dedup, 3 of those are valid across 2 windows
    job_015 = summary["job_summaries"]["job_015"]
    assert job_015["windows_spanned"] == [1, 2], \
        f"job_015 should span windows [1, 2], got {job_015['windows_spanned']}"


# --- Window rollover tests (hidden semantic edge cases) ---

def test_window_scoped_retry_counts():
    """Verify retry counts reset at window boundaries."""
    summary = load_summary()
    # job_002 appears in windows 0, 1, and 2
    # With window-scoped resets: should have total_attempts=4 (not exceeding max)
    job_002 = summary["job_summaries"]["job_002"]
    assert job_002["total_attempts"] == 4, \
        f"job_002 should have 4 total attempts with window-scoped counting, got {job_002['total_attempts']}"


def test_cross_window_job_not_dropped():
    """Verify jobs spanning multiple windows are not incorrectly dropped."""
    summary = load_summary()
    dropped_ids = [d["job_id"] for d in summary["dropped_jobs"]]
    # With window-scoped counting, no job should be dropped
    cross_window_jobs = ["job_001", "job_002", "job_003", "job_006", "job_015"]
    for jid in cross_window_jobs:
        assert jid not in dropped_ids, \
            f"{jid} was incorrectly dropped despite window-scoped retry counting"
    # All cross-window jobs should appear in final queue exactly once
    queue_jobs = summary["final_queue_order"]
    for jid in cross_window_jobs:
        count = queue_jobs.count(jid)
        assert count == 1, \
            f"{jid} appears {count} times in queue (expected exactly 1)"


def test_event_total_consistency():
    """Verify total events + deduplicated = raw input count handled correctly."""
    summary = load_summary()
    # total_events_processed should only count non-deduplicated events
    # total_deduplicated + total_events_processed should account for all input events that weren't dropped pre-dedup
    assert summary["total_events_processed"] + summary["total_deduplicated"] == 50, \
        f"Events processed ({summary['total_events_processed']}) + deduplicated ({summary['total_deduplicated']}) should equal 50 raw events"


def test_window_0_event_count():
    """Verify window 0 processed correct number of events."""
    summary = load_summary()
    assert len(summary["window_stats"]) >= 2, "Expected at least 2 window stat entries"
    w0 = summary["window_stats"][0]
    assert w0["events_processed"] == 13, \
        f"Window 0 should have 13 events, got {w0['events_processed']}"
    # Window 0 queue size should reflect deduplicated, single-entry-per-job state
    assert w0["queue_size"] == 9, \
        f"Window 0 queue size should be 9 at transition, got {w0['queue_size']}"


def test_window_1_event_count():
    """Verify window 1 processed correct number of events."""
    summary = load_summary()
    w1 = summary["window_stats"][1]
    assert w1["events_processed"] == 14, \
        f"Window 1 should have 14 events, got {w1['events_processed']}"


# --- Backoff calculation tests ---

def test_backoff_first_attempt_uses_base_delay():
    """Verify first retry attempt uses approximately base_delay (not multiplied)."""
    summary = load_summary()
    # With correct backoff: first attempt delay ~ base_delay + jitter
    # job_004 only has 1 attempt, so its queue position reflects base_delay timing
    queue_order = summary["final_queue_order"]
    # job_004 first seen at 1015.0, with correct backoff (attempt=1, exponent=0)
    # delay should be ~100ms + small jitter, placing it early in queue
    idx_004 = queue_order.index("job_004")
    assert idx_004 < 5, \
        f"job_004 with single attempt should be near front of queue (idx={idx_004})"


def test_multi_worker_attribution():
    """Verify jobs processed by multiple workers track all workers."""
    summary = load_summary()
    job_002 = summary["job_summaries"]["job_002"]
    assert sorted(job_002["workers"]) == ["node_a", "node_d", "node_e"], \
        f"job_002 workers should be ['node_a', 'node_d', 'node_e'], got {job_002['workers']}"
