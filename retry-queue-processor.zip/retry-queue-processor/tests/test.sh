#!/bin/bash
# Run the processor and then validate outputs
cd /app/runtime && python3 run_processor.py

# Run test suite
pytest /tests/test_outputs.py -rA
